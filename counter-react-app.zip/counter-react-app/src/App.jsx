import { useState } from "react"

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="container">
      <div className="card">
        <h1>Counter App</h1>
        <div className="count">{count}</div>

        <div className="buttons">
          <button className="minus" onClick={() => setCount(count - 1)}>
            −
          </button>
          <button className="plus" onClick={() => setCount(count + 1)}>
            +
          </button>
        </div>
      </div>
    </div>
  )
}

export default App
